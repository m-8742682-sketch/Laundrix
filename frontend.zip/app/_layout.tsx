/**
 * Root Layout — app/_layout.tsx
 *
 * CRITICAL: polyfills imported FIRST — patches global.Event / EventTarget / AbortController
 * for LiveKit SDK. Without this: ReferenceError: Property 'Event' doesn't exist
 */

// ── MUST BE ABSOLUTE FIRST IMPORT ────────────────────────────────────────────
import '@/polyfills';
// ─────────────────────────────────────────────────────────────────────────────

import { AuthProvider } from '@/components/UserContext';
import { I18nProvider } from '@/i18n/i18n';
import * as SplashScreen from 'expo-splash-screen';
import { auth } from '@/services/firebase';
import { Stack, router } from 'expo-router';
import { onAuthStateChanged } from 'firebase/auth';
import { useEffect, useRef } from 'react';
import { StyleSheet, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { registerGlobals } from '@livekit/react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import {
  initializeNotifications,
  ensureNotificationChannels,
  addNotificationResponseListener,
  addNotificationReceivedListener,
} from '@/services/notification.service';
import { warmupBackend } from '@/services/api';
import GraceAlarmModal from '@/components/GraceAlarmModal';
import CallAudioController from '@/components/CallAudioController';
import GlobalSoundController from '@/components/GlobalSoundController';
import ActiveCallOverlay from '@/app/call/_ActiveCallOverlay';
import IncomingCallOverlay from '@/app/call/_IncomingCallOverlay';
import OutgoingCallOverlay from '@/app/call/_OutgoingCallOverlay';
import NotificationPopup from '@/components/NotificationPopup';
import GlobalIncidentModal from '@/components/incident/GlobalIncidentModal';

// Must be called before any LiveKit Room/Track usage
registerGlobals();
SplashScreen.preventAutoHideAsync();

// ─── CRITICAL: Background FCM handler — MUST be at module level, NOT inside useEffect ──────────
// When app is killed or backgrounded, Firebase spawns a headless JS task.
// React never mounts, so useEffect-based handlers are NEVER registered.
// This module-level code runs immediately when the JS bundle loads.
try {
  const { getMessaging, setBackgroundMessageHandler } =
    require('@react-native-firebase/messaging');
  const { getApp } = require('@react-native-firebase/app');

  setBackgroundMessageHandler(getMessaging(getApp()), async (msg: any) => {
    const type    = msg.data?.type ?? '';
    const isCall  = type === 'voice_call' || type === 'video_call';
    const isGrace = type === 'your_turn';
    const isAlert = type === 'unauthorized_alert';
    const isCritical = isCall || isGrace || isAlert;
    console.log('[FCM BG] Received:', type, '| critical:', isCritical);

    if (!isCritical) return;

    try {
      const Notifications = require('expo-notifications');
      const { Platform } = require('react-native');

      // ── Step 1: Ensure notification channels exist in headless context ──
      // React components aren't mounted here so createNotificationChannels() never ran.
      if (Platform.OS === 'android') {
        const channelDefs = [
          { id: 'calls',    importance: 5, sound: 'calling.mp3', vibrate: [0,500,200,500,200,500], bypassDnd: true  },
          { id: 'critical', importance: 5, sound: 'alarm.mp3',   vibrate: [0,500,200,500,200,500], bypassDnd: true  },
          { id: 'urgent',   importance: 4, sound: 'urgent.mp3',  vibrate: [0,300,150,300],         bypassDnd: false },
        ];
        for (const ch of channelDefs) {
          await Notifications.setNotificationChannelAsync(ch.id, {
            name:                ch.id,
            importance:          ch.importance,
            sound:               ch.sound,
            vibrationPattern:    ch.vibrate,
            lockscreenVisibility: 1, // PUBLIC
            bypassDnd:           ch.bypassDnd,
          });
        }
      }

      // ── Step 2: Resolve channel + sound ──
      const channelId = isCall ? 'calls' : 'critical';
      const sound     = isCall ? 'calling.mp3' : 'alarm.mp3';
      const title     = msg.notification?.title || msg.data?.title || '🔔 Laundrix';
      const body      = msg.notification?.body  || msg.data?.body  || '';

      // ── Step 3: Schedule with correct channel so heads-up fires at MAX importance ──
      await Notifications.scheduleNotificationAsync({
        content: {
          title,
          body,
          data:  msg.data,
          sound,
          ...(Platform.OS === 'ios' ? { sound } : {}),
        },
        trigger:  null,
        // Android channel drives importance/sound/vibration — MUST match the channel
        // created above. Without this the notification falls back to 'default' (low importance)
        // and never shows as a heads-up or lock-screen overlay.
        ...(Platform.OS === 'android' ? { android: { channelId, sticky: isCall } } as any : {}),
      });

      console.log('[FCM BG] Local notification scheduled on channel:', channelId);
    } catch (e) {
      console.warn('[FCM BG] local notification failed:', e);
    }
  });
  console.log('[FCM] Background handler registered at module level ✓');
} catch (e) {
  console.warn('[FCM] Background handler module-level setup failed:', e);
}
// ─────────────────────────────────────────────────────────────────────────────

function handleNotificationNavigation(data: Record<string, any> | undefined): void {
  if (!data) return;
  const type = data.type ?? '';

  if (['your_turn', 'grace_warning', 'removed_from_queue', 'queue_joined',
       'queue_left', 'queue_reminder'].includes(type)) {
    router.push('/(tabs)/queue');
  } else if (['session_started', 'session_ended', 'clothes_ready'].includes(type)) {
    router.push('/(tabs)/dashboard');
  } else if (['unauthorized_alert', 'unauthorized_warning', 'buzzer_triggered'].includes(type)) {
    router.push('/(tabs)/queue');
  } else if (type === 'chat_message') {
    router.push('/(tabs)/conversations');
  } else if (type === 'voice_call') {
    router.push({
      pathname: '/call/voice-incoming',
      params: {
        channel:  String(data.callId    || ''),
        name:     String(data.callerName || 'Unknown'),
        callerId: String(data.callerId  || ''),
      },
    });
  } else if (type === 'video_call') {
    router.push({
      pathname: '/call/video-incoming',
      params: {
        channel:  String(data.callId    || ''),
        name:     String(data.callerName || 'Unknown'),
        callerId: String(data.callerId  || ''),
      },
    });
  } else if (['missed_call', 'missedCall', 'missed_video', 'missedVideo'].includes(type)) {
    router.push('/(tabs)/conversations');
  }
}

export default function RootLayout() {
  const hasNavigated = useRef(false);

  useEffect(() => {
    warmupBackend();
    ensureNotificationChannels().catch(() => {});

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (hasNavigated.current) return;
      hasNavigated.current = true;

      const hasLaunched = await AsyncStorage.getItem('hasLaunched');

      if (!hasLaunched) {
        await SplashScreen.hideAsync();
        router.replace('/(onboarding)');
        return;
      }

      await SplashScreen.hideAsync();

      if (user) {
        initializeNotifications(user.uid).catch((err) =>
          console.warn('[Layout] Notification init failed:', err)
        );
        router.replace('/(tabs)/dashboard');
      } else {
        router.replace('/(auth)/login');
      }
    });

    return unsubscribe;
  }, []);

  // expo-notifications tap & receive handlers
  useEffect(() => {
    const responseSub = addNotificationResponseListener((response) => {
      const data = response.notification.request.content.data;
      console.log('[Notification] Tapped:', data?.type);
      handleNotificationNavigation(data as any);
    });
    const receivedSub = addNotificationReceivedListener((notification) => {
      console.log('[Notification] Foreground:', notification.request.content.title);
    });
    return () => { responseSub.remove(); receivedSub.remove(); };
  }, []);

  // FCM killed / background state tap handlers
  useEffect(() => {
    let unsubOpen: (() => void) | null = null;
    try {
      const {
        getMessaging, getInitialNotification, onNotificationOpenedApp,
      } = require('@react-native-firebase/messaging');
      const { getApp } = require('@react-native-firebase/app');
      const messaging = getMessaging(getApp());

      getInitialNotification(messaging).then((msg: any) => {
        if (msg?.data) {
          console.log('[FCM] Opened from killed state:', msg.notification?.title);
          setTimeout(() => handleNotificationNavigation(msg.data), 500);
        }
      });

      unsubOpen = onNotificationOpenedApp(messaging, (msg: any) => {
        if (msg?.data) {
          console.log('[FCM] Opened from background:', msg.notification?.title);
          handleNotificationNavigation(msg.data);
        }
      });
    } catch (e) {
      console.warn('[FCM] Notification open handler setup failed:', e);
    }
    return () => { unsubOpen?.(); };
  }, []);

  return (
    <GestureHandlerRootView style={s.container}>
      <I18nProvider>
        <AuthProvider>
          <View style={s.container}>
            <Stack
              screenOptions={{
                headerShown: false,
                gestureEnabled: true,
                gestureDirection: 'horizontal',
                animation: 'fade',
              }}
            >
              <Stack.Screen name="(tabs)"       options={{ animation: 'fade',              gestureEnabled: false }} />
              <Stack.Screen name="(auth)"       options={{ animation: 'fade',              gestureEnabled: false }} />
              <Stack.Screen name="(onboarding)" options={{ animation: 'fade',              gestureEnabled: false }} />
              <Stack.Screen name="(settings)"   options={{ animation: 'fade',              gestureEnabled: true, gestureDirection: 'horizontal' }} />
              <Stack.Screen name="call"         options={{ animation: 'fade',              gestureEnabled: false }} />
              <Stack.Screen name="iot"          options={{ animation: 'fade',              gestureEnabled: true, gestureDirection: 'horizontal' }} />
              <Stack.Screen name="qrscan"       options={{ animation: 'fade',              gestureEnabled: true, gestureDirection: 'horizontal' }} />
              <Stack.Screen name="admin"        options={{ animation: 'fade',              gestureEnabled: true, gestureDirection: 'horizontal' }} />
            </Stack>

            {/* ── Global overlays (render above ALL screens) ──────────── */}
            <GlobalSoundController />
            <CallAudioController />
            <IncomingCallOverlay />
            <OutgoingCallOverlay />
            <ActiveCallOverlay />
            <GraceAlarmModal />
            <GlobalIncidentModal />
            <NotificationPopup />
          </View>
        </AuthProvider>
      </I18nProvider>
    </GestureHandlerRootView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1 },
});
