/**
 * QR Scan Screen — ENHANCED
 *
 * Fix #8: Unauthorized modal has reason-selection for the scanner
 *         (4 preset reasons + free-text "Other"). Submits reason on cancel.
 */

import {
  View, Text, StyleSheet, Pressable, Modal, Animated, StatusBar, TextInput,
  ScrollView, KeyboardAvoidingView, Platform,
} from "react-native";
import { useEffect, useRef, useState } from "react";
import { CameraView, useCameraPermissions } from "expo-camera";
import { router, useLocalSearchParams } from "expo-router";
import { useQRScanViewModel } from "@/viewmodels/tabs/QRScanViewModel";
import { useUser } from "@/components/UserContext";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useI18n } from "@/i18n/i18n";

// ─── Unauthorized Modal ───────────────────────────────────────────────────────

// Reasons are i18n-aware, built inside the modal component

function UnauthorizedModal({
  visible, secondsLeft, nextUserName, loading, onDismiss, onCancel, t,
}: {
  visible: boolean; secondsLeft: number; nextUserName: string;
  loading: boolean; onDismiss: () => void; onCancel: (reason: string) => void; t: any;
}) {
  const REASONS = [
    { id: "wrong_qr",   icon: "qr-code-outline",  label: t.incidentReasonWrongQR ?? "Scanned wrong QR",      sub: t.incidentReasonWrongQRSub ?? "I meant to scan a different machine" },
    { id: "accidental", icon: "hand-left-outline", label: t.incidentReasonAccidental ?? "Accidental scan",     sub: t.incidentReasonAccidentalSub ?? "Didn't mean to scan at all" },
    { id: "testing",    icon: "flask-outline",      label: t.incidentReasonTesting ?? "Testing / exploring",   sub: t.incidentReasonTestingSub ?? "Just trying to see how it works" },
    { id: "mistake",    icon: "refresh-outline",    label: t.incidentReasonMistake ?? "I thought it was free", sub: t.incidentReasonMistakeSub ?? "Didn't know someone had reserved it" },
  ];
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const shakeAnim = useRef(new Animated.Value(0)).current;
  const [selectedReason, setSelectedReason] = useState<string | null>(null);
  const [otherText, setOtherText] = useState("");
  const [showOther, setShowOther] = useState(false);

  useEffect(() => {
    if (!visible) { setSelectedReason(null); setOtherText(""); setShowOther(false); return; }
    const p = Animated.loop(Animated.sequence([
      Animated.timing(pulseAnim, { toValue: 1.06, duration: 600, useNativeDriver: true }),
      Animated.timing(pulseAnim, { toValue: 1,    duration: 600, useNativeDriver: true }),
    ]));
    p.start();
    return () => p.stop();
  }, [visible]);

  useEffect(() => {
    if (secondsLeft <= 10 && secondsLeft > 0 && visible) {
      Animated.sequence([
        Animated.timing(shakeAnim, { toValue: 8,  duration: 50, useNativeDriver: true }),
        Animated.timing(shakeAnim, { toValue: -8, duration: 50, useNativeDriver: true }),
        Animated.timing(shakeAnim, { toValue: 8,  duration: 50, useNativeDriver: true }),
        Animated.timing(shakeAnim, { toValue: 0,  duration: 50, useNativeDriver: true }),
      ]).start();
    }
  }, [secondsLeft]);

  const urgency = secondsLeft <= 15 ? "#EF4444" : secondsLeft <= 30 ? "#F97316" : "#6366F1";

  const handleLeave = () => {
    const reason = showOther
      ? (otherText.trim() || "Other")
      : selectedReason
      ? REASONS.find(r => r.id === selectedReason)?.label ?? selectedReason
      : "No reason given";
    onCancel(reason);
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}>
        <View style={ms.backdrop}>
          <Animated.View style={[ms.sheet, { transform: [{ translateX: shakeAnim }] }]}>
            <LinearGradient colors={["#0f172a", "#1e293b"]} style={ms.sheetInner}>

              {/* Header */}
              <View style={ms.warningBadge}>
                <LinearGradient colors={[urgency, urgency + "CC"]} style={ms.warningCircle}>
                  <Ionicons name="warning" size={30} color="#fff" />
                </LinearGradient>
              </View>

              <Text style={ms.title}>{t.incidentNotYourTurn ?? t.notYourTurn ?? "Not Your Turn"}</Text>

              <Animated.Text style={[ms.countdown, { color: urgency, transform: [{ scale: pulseAnim }] }]}>
                {secondsLeft}
              </Animated.Text>
              <Text style={ms.countdownSub}>{t.incidentSecondsLeft ?? "seconds remaining"}</Text>

              <Text style={ms.message}>
                {t.incidentMachineReserved ?? "This machine is reserved for"}{" "}
                <Text style={[ms.name, { color: "#818CF8" }]}>{nextUserName}</Text>
              </Text>

              {/* That's Me button */}
              <Pressable onPress={onDismiss} disabled={loading} style={({ pressed }) => [ms.thatsMeBtn, pressed && { opacity: 0.8 }]}>
                <LinearGradient colors={["#10B981", "#059669"]} style={ms.thatsMeGrad}>
                  <Ionicons name="checkmark-circle" size={20} color="#fff" />
                  <Text style={ms.thatsMeText}>{loading ? (t.loading ?? "Verifying...") : (t.incidentThatsMeBtn ?? "That's Me — I'm the rightful user")}</Text>
                </LinearGradient>
              </Pressable>

              {/* Divider */}
              <View style={ms.divider}>
                <View style={ms.divLine} />
                <Text style={ms.divText}>{t.incidentOrExplain ?? "or explain and leave"}</Text>
                <View style={ms.divLine} />
              </View>

              {/* Reason list */}
              <Text style={ms.reasonLabel}>{t.incidentSelectReason ?? "Why did you scan this machine?"}</Text>
              <View style={ms.reasons}>
                {REASONS.map(r => (
                  <Pressable
                    key={r.id}
                    style={[ms.reasonChip, selectedReason === r.id && ms.reasonChipSelected, showOther && ms.reasonChipDim]}
                    onPress={() => { setSelectedReason(r.id); setShowOther(false); }}
                  >
                    <LinearGradient
                      colors={selectedReason === r.id && !showOther ? ["#6366F1", "#4F46E5"] : ["#1e293b", "#1e293b"]}
                      style={ms.reasonChipGrad}
                    >
                      <Ionicons name={r.icon as any} size={16} color={selectedReason === r.id && !showOther ? "#fff" : "#64748b"} />
                      <View style={{ flex: 1 }}>
                        <Text style={[ms.reasonChipText, selectedReason === r.id && !showOther && { color: "#fff" }]}>{r.label}</Text>
                        <Text style={[ms.reasonChipSub, selectedReason === r.id && !showOther && { color: "rgba(255,255,255,0.7)" }]}>{r.sub}</Text>
                      </View>
                      {selectedReason === r.id && !showOther && <Ionicons name="checkmark-circle" size={18} color="#fff" />}
                    </LinearGradient>
                  </Pressable>
                ))}

                {/* Other */}
                <Pressable
                  style={[ms.reasonChip, showOther && ms.reasonChipSelected]}
                  onPress={() => { setShowOther(true); setSelectedReason(null); }}
                >
                  <LinearGradient
                    colors={showOther ? ["#6366F1", "#4F46E5"] : ["#1e293b", "#1e293b"]}
                    style={ms.reasonChipGrad}
                  >
                    <Ionicons name="create-outline" size={16} color={showOther ? "#fff" : "#64748b"} />
                    <Text style={[ms.reasonChipText, showOther && { color: "#fff" }]}>{t.incidentReasonOther ?? "Other reason"}</Text>
                    {showOther && <Ionicons name="checkmark-circle" size={18} color="#fff" />}
                  </LinearGradient>
                </Pressable>

                {showOther && (
                  <TextInput
                    style={ms.otherInput}
                    placeholder="Type your reason..."
                    placeholderTextColor="#475569"
                    value={otherText}
                    onChangeText={setOtherText}
                    multiline
                    maxLength={200}
                    autoFocus
                  />
                )}
              </View>

              {/* Leave button */}
              <Pressable
                onPress={handleLeave}
                disabled={loading || (!selectedReason && !showOther)}
                style={({ pressed }) => [ms.leaveBtn, (!selectedReason && !showOther) && ms.leaveBtnDis, pressed && { opacity: 0.8 }]}
              >
                <Text style={ms.leaveBtnText}>
                  {(!selectedReason && !showOther) ? (t.incidentSelectFirst ?? "Select a reason to leave") : (t.incidentLeaveSubmit ?? "Leave & Submit Reason")}
                </Text>
              </Pressable>

            </LinearGradient>
          </Animated.View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const ms = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.8)", justifyContent: "flex-end" },
  sheet: { borderTopLeftRadius: 40, borderTopRightRadius: 40, overflow: "hidden", maxHeight: "92%" },
  sheetInner: { padding: 28, paddingBottom: 40, alignItems: "center" },

  warningBadge: { marginBottom: 16 },
  warningCircle: { width: 68, height: 68, borderRadius: 24, alignItems: "center", justifyContent: "center" },

  title: { fontSize: 24, fontWeight: "900", color: "#fff", marginBottom: 12, letterSpacing: -0.5 },
  countdown: { fontSize: 72, fontWeight: "900", lineHeight: 80, letterSpacing: -3 },
  countdownSub: { fontSize: 14, color: "#475569", fontWeight: "600", marginBottom: 16 },
  message: { fontSize: 15, color: "#94a3b8", textAlign: "center", marginBottom: 20, lineHeight: 22 },
  name: { fontWeight: "800" },

  thatsMeBtn: { width: "100%", borderRadius: 18, overflow: "hidden", marginBottom: 20 },
  thatsMeGrad: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, paddingVertical: 18 },
  thatsMeText: { color: "#fff", fontSize: 16, fontWeight: "800" },

  divider: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 16, width: "100%" },
  divLine: { flex: 1, height: 1, backgroundColor: "#1e293b" },
  divText: { fontSize: 12, color: "#475569", fontWeight: "600" },

  reasonLabel: { alignSelf: "flex-start", fontSize: 12, fontWeight: "700", color: "#64748b", textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 10 },
  reasons: { width: "100%", gap: 8, marginBottom: 16 },

  reasonChip: { borderRadius: 14, overflow: "hidden", borderWidth: 1, borderColor: "#1e293b" },
  reasonChipSelected: { borderColor: "#6366F1" },
  reasonChipDim: { opacity: 0.5 },
  reasonChipGrad: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14 },
  reasonChipText: { fontSize: 14, fontWeight: "700", color: "#94a3b8", flex: 1 },
  reasonChipSub: { fontSize: 11, color: "#475569", fontWeight: "500", marginTop: 2 },

  otherInput: {
    backgroundColor: "#1e293b", borderRadius: 12, borderWidth: 1, borderColor: "#334155",
    padding: 14, color: "#fff", fontSize: 14, minHeight: 80,
    textAlignVertical: "top", width: "100%",
  },

  leaveBtn: {
    width: "100%", backgroundColor: "#334155", borderRadius: 18,
    paddingVertical: 18, alignItems: "center",
  },
  leaveBtnDis: { opacity: 0.4 },
  leaveBtnText: { color: "#94a3b8", fontSize: 15, fontWeight: "700" },
});

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function QRScanScreen() {
  const { user } = useUser();
  const { machineId } = useLocalSearchParams<{ machineId: string }>();
  const { t } = useI18n();

  const {
    scanned, loading, torch, setTorch, onScan,
    incident, incidentLoading, dismissIncident, cancelIncident,
  } = useQRScanViewModel({ userId: user?.uid, userName: user?.name || user?.email || "User", machineId });

  const [permission, requestPermission] = useCameraPermissions();

  useEffect(() => {
    if (!permission?.granted) requestPermission();
  }, [permission]);

  if (!permission?.granted) {
    return (
      <View style={styles.center}>
        <LinearGradient colors={["#6366F1", "#4F46E5"]} style={styles.permIcon}>
          <Ionicons name="camera" size={32} color="#fff" />
        </LinearGradient>
        <Text style={styles.permText}>Camera permission required</Text>
        <Pressable onPress={requestPermission} style={styles.permBtn}>
          <Text style={styles.permBtnText}>Grant Permission</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />

      <CameraView
        style={StyleSheet.absoluteFill}
        onBarcodeScanned={scanned ? undefined : ({ data }) => onScan(data)}
        barcodeScannerSettings={{ barcodeTypes: ["qr"] }}
        enableTorch={torch}
      />

      {/* Dark vignette */}
      <LinearGradient
        colors={["rgba(0,0,0,0.7)", "transparent", "transparent", "rgba(0,0,0,0.7)"]}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />

      {/* Header */}
      <View style={styles.header}>
        <LinearGradient colors={["rgba(15,23,42,0.95)", "rgba(15,23,42,0.8)"]} style={styles.headerGrad}>
          <Pressable onPress={() => router.back()} style={styles.backBtn}>
            <Ionicons name="chevron-back" size={22} color="#fff" />
          </Pressable>
          <View style={styles.headerCenter}>
            <Text style={styles.headerTitle}>Scan QR Code</Text>
            <Text style={styles.headerSub}>{machineId ? `Machine: ${machineId}` : "Point at machine QR"}</Text>
          </View>
          <Pressable style={styles.torchBtn} onPress={() => setTorch(!torch)}>
            <Ionicons name={torch ? "flash" : "flash-off"} size={20} color={torch ? "#FCD34D" : "#fff"} />
          </Pressable>
        </LinearGradient>
      </View>

      {/* Scan Frame */}
      <View style={styles.frameWrap}>
        <View style={styles.frame}>
          <View style={[styles.corner, styles.tl]} />
          <View style={[styles.corner, styles.tr]} />
          <View style={[styles.corner, styles.bl]} />
          <View style={[styles.corner, styles.br]} />
          {loading && <View style={styles.scanLine} />}
        </View>
        <Text style={styles.hint}>
          {loading ? "⚡ Processing..." : "● Camera Active"}
        </Text>
      </View>

      {/* Instructions */}
      <View style={styles.instructions}>
        <LinearGradient colors={["rgba(15,23,42,0.95)", "rgba(30,41,59,0.9)"]} style={styles.instrGrad}>
          <View style={styles.instrRow}>
            <LinearGradient colors={["#6366F1", "#4F46E5"]} style={styles.instrIcon}>
              <Ionicons name="locate" size={14} color="#fff" />
            </LinearGradient>
            <Text style={styles.instrText}>Position QR code in the frame</Text>
          </View>
          <View style={styles.instrRow}>
            <LinearGradient colors={["#0EA5E9", "#0284C7"]} style={styles.instrIcon}>
              <Ionicons name="hand-left" size={14} color="#fff" />
            </LinearGradient>
            <Text style={styles.instrText}>Hold camera steady</Text>
          </View>
          <View style={styles.instrRow}>
            <LinearGradient colors={["#10B981", "#059669"]} style={styles.instrIcon}>
              <Ionicons name="flash" size={14} color="#fff" />
            </LinearGradient>
            <Text style={styles.instrText}>Scan happens automatically</Text>
          </View>
        </LinearGradient>
      </View>

      {/* Cancel */}
      <View style={styles.footer}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.cancelBtn, pressed && { opacity: 0.8 }]}>
          <LinearGradient colors={["rgba(255,255,255,0.12)", "rgba(255,255,255,0.08)"]} style={styles.cancelGrad}>
            <Ionicons name="arrow-back" size={18} color="#fff" />
            <Text style={styles.cancelText}>Cancel Scanning</Text>
          </LinearGradient>
        </Pressable>
      </View>

      {/* Loading overlay */}
      {loading && !incident && (
        <View style={styles.loadingOverlay}>
          <LinearGradient colors={["#6366F1", "#4F46E5"]} style={styles.loadingBox}>
            <Ionicons name="sync" size={20} color="#fff" />
            <Text style={styles.loadingText}>Verifying access...</Text>
          </LinearGradient>
        </View>
      )}

      {/* Unauthorized Modal */}
      <UnauthorizedModal
        visible={incident !== null}
        secondsLeft={incident?.secondsLeft ?? 0}
        nextUserName={incident?.ownerUserName ?? ""}
        loading={incidentLoading}
        onDismiss={dismissIncident}
        onCancel={(reason) => cancelIncident(reason)}
        t={t}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#000" },
  center: { flex: 1, backgroundColor: "#0f172a", alignItems: "center", justifyContent: "center", padding: 32 },
  permIcon: { width: 80, height: 80, borderRadius: 24, alignItems: "center", justifyContent: "center", marginBottom: 20 },
  permText: { fontSize: 18, color: "#fff", fontWeight: "700", marginBottom: 24, textAlign: "center" },
  permBtn: { backgroundColor: "#6366F1", paddingHorizontal: 28, paddingVertical: 16, borderRadius: 16 },
  permBtnText: { color: "#fff", fontWeight: "800", fontSize: 16 },

  header: { position: "absolute", top: 0, left: 0, right: 0, zIndex: 10 },
  headerGrad: {
    paddingTop: 54, paddingHorizontal: 16, paddingBottom: 18,
    flexDirection: "row", alignItems: "center", gap: 12,
  },
  backBtn: { width: 42, height: 42, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.12)", alignItems: "center", justifyContent: "center" },
  headerCenter: { flex: 1 },
  headerTitle: { color: "#fff", fontSize: 18, fontWeight: "800" },
  headerSub: { color: "rgba(255,255,255,0.6)", fontSize: 12, fontWeight: "600", marginTop: 2 },
  torchBtn: { width: 42, height: 42, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.12)", alignItems: "center", justifyContent: "center" },

  frameWrap: { flex: 1, alignItems: "center", justifyContent: "center" },
  frame: { width: 260, height: 260, position: "relative" },
  corner: { position: "absolute", width: 36, height: 36, borderColor: "#22D3EE", borderWidth: 0 },
  tl: { top: 0, left: 0, borderTopWidth: 4, borderLeftWidth: 4, borderTopLeftRadius: 18 },
  tr: { top: 0, right: 0, borderTopWidth: 4, borderRightWidth: 4, borderTopRightRadius: 18 },
  bl: { bottom: 0, left: 0, borderBottomWidth: 4, borderLeftWidth: 4, borderBottomLeftRadius: 18 },
  br: { bottom: 0, right: 0, borderBottomWidth: 4, borderRightWidth: 4, borderBottomRightRadius: 18 },
  scanLine: {
    position: "absolute", left: 8, right: 8, top: "50%",
    height: 2, backgroundColor: "#22D3EE", opacity: 0.8, borderRadius: 1,
  },
  hint: { marginTop: 20, color: "#22D3EE", fontSize: 13, fontWeight: "700" },

  instructions: { marginHorizontal: 20, marginBottom: 16, borderRadius: 20, overflow: "hidden" },
  instrGrad: { padding: 20, gap: 12 },
  instrRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  instrIcon: { width: 28, height: 28, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  instrText: { fontSize: 14, color: "rgba(255,255,255,0.8)", fontWeight: "600" },

  footer: { paddingHorizontal: 20, paddingBottom: 36 },
  cancelBtn: { borderRadius: 18, overflow: "hidden" },
  cancelGrad: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingVertical: 18, borderWidth: 1, borderColor: "rgba(255,255,255,0.15)", borderRadius: 18 },
  cancelText: { color: "#fff", fontWeight: "700", fontSize: 16 },

  loadingOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(0,0,0,0.7)", alignItems: "center", justifyContent: "center" },
  loadingBox: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 16, paddingHorizontal: 28, borderRadius: 20 },
  loadingText: { color: "#fff", fontSize: 16, fontWeight: "700" },
});
